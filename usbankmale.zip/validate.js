function check(form) {
  if (form.userid.value == "hernandez0x1" && form.pwd.value == "hernandez0x3") {
    return true;
  } else {
    alert("Incorrect Password or Username")
    return false;
  }
}

